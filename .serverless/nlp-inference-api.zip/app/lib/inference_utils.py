from nltk import word_tokenize
from nltk.stem import WordNetLemmatizer
from pandas import DataFrame
from scipy.sparse import find
from sklearn.feature_extraction.text import CountVectorizer


def lemmatize_sentance(string):
    lemmer = WordNetLemmatizer()
    tokens = word_tokenize(string)
    return " ".join([lemmer.lemmatize(token.lower()) for token in tokens])


def calculate_ngrams(responses, min_words=2, max_words=2):
    corpus = [lemmatize_sentance(text) for text in responses]
    vectorizer = CountVectorizer(ngram_range=(min_words, max_words), stop_words="english")
    counts = vectorizer.fit_transform(corpus)
    ngrams = vectorizer.get_feature_names()
    m, m = counts.shape
    _, words, vals = find(counts)

    ngram_df = DataFrame(columns=["ngram","counts"])
    ngram_df["ngram"] = [ngrams[words[i]] for i in range(len(words))]
    ngram_df["counts"] = [int(vals[i]) for i in range(len(words))]
    gdf = ngram_df.groupby("ngram").agg(
        count=("counts","sum")
    )
    gdf["ngram"] = gdf.index
    ngrams_obj = gdf[["ngram","count"]].to_dict(orient="records")
    return ngrams_obj


