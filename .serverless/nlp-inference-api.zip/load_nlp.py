import nltk

if __name__ == "__main__":
    nltk.download("averaged_perceptron_tagger",download_dir='nltk_data/')
    nltk.download("punkt",download_dir='nltk_data/')
    nltk.download("wordnet",download_dir='nltk_data/')
    nltk.download("stopwords",download_dir='nltk_data/')
